import { Navigation } from "../components/Navigation";
import { Hero } from "../components/Hero";
import { Services } from "../components/Services";
import { Process } from "../components/Process";
import { PremiumPack } from "../components/PremiumPack";
import { Portfolio } from "../components/Portfolio";
import { WhyChooseUs } from "../components/WhyChooseUs";
import { Contact } from "../components/Contact";
import { FloatingButtons } from "../components/FloatingButtons";
import { Footer } from "../components/Footer";

export default function Home() {
  return (
    <div className="bg-background text-foreground min-h-screen font-sans selection:bg-primary/30 selection:text-white">
      <Navigation />
      <main>
        <Hero />
        <Services />
        <Process />
        <PremiumPack />
        <Portfolio />
        <WhyChooseUs />
        <Contact />
      </main>
      <Footer />
      <FloatingButtons />
    </div>
  );
}
